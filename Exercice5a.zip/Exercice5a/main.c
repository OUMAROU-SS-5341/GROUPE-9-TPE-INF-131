#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define pi 3.14

int main()
{
    /* Ce programme permet de calculer le volume d'une sph�re sachant son rayon */
    float V, r;
    printf("Entrez le rayon de la sphere\n");
    scanf("%f",&r);
      V = 4 * pi * r * r * r/3;
      printf("le volume de la sphere est :%f", V);
    return 0;
}
