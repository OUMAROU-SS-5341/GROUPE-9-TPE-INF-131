#include <stdio.h>
#include <stdlib.h>

int main()
{
    /*Ce programme demande a l'utilisateur un nombre et l'informe ensuite s'il est positif negatif ou nul*/
    int nombre;
     printf("Entrez un nombre \n");
    scanf("%d",&nombre);
    if(nombre<0)
    {
        printf("%d est negatif",nombre);
    }
    else
    {
        if(nombre>0)
        {
            printf("%d est positif",nombre);
        }
        else{
            printf("%d est nul",nombre);
        }
    }
    return 0;
}
