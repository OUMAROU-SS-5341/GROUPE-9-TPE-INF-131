#include <stdio.h>
#include <math.h>

int main()
{
    /* Ce programme  permet la saisie de calculer la somme de suite de nombres entr�es par l'utilisateur se terminant par 0 */
    int S, i;
    S=0;
    do{
        printf("Enrez une valeur:\n");
        scanf("%d", &i);
        S=S+i;
    }
    while(i!=0);
    printf("La somme des entiers est de %d\n",S);
    return 0;
}
