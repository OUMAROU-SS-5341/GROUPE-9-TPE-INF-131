#include <stdio.h>
#include <stdlib.h>
    struct Date{
    int jour;
    int mois;
    int annee;
    };
    int comparaisonDate(struct Date date1,struct Date date2)
    {
        int retour=0;
         if(date1.annee>date2.annee)
        {
            retour=1;
        }
        else
        {
            if(date1.annee<date2.annee)
            {
                retour=0;
            }
            else{
                    if(date1.mois>date2.mois)
                    {
                        retour=1;
                    }
                    else
                    {
                        if(date1.mois<date2.mois)
                        {
                            retour=0;
                        }
                        else
                        {
                            if(date1.jour>date2.jour)
                            {
                                retour=1;
                            }
                            else
                            {
                                if(date1.jour<date2.jour)
                                {
                                    retour=0;
                                }
                                else
                                {
                                    retour=2;
                                }
                            }
                        }
                    }
            }
        }
        return retour;

    }

int main()
{
    int retour;
    struct Date date1;
    struct Date date2;
   printf("*** Saisie de la date 1 *** \n");
   printf("Entrez l'annee \n");
   scanf("%d",&date1.annee);
   printf("Entrez le mois \n");
   scanf("%d",&date1.mois);
   printf("Entrez le jour \n");
   scanf("%d",&date1.jour);

    printf("*** Saisie de la date 2 *** \n");
   printf("Entrez l'annee \n");
   scanf("%d",&date2.annee);
   printf("Entrez le mois \n");
   scanf("%d",&date2.mois);
   printf("Entrez le jour \n");
   scanf("%d",&date2.jour);


   retour=comparaisonDate(date1,date2);

        if(retour==0)
        {
            printf("Date 1 vient avant Date 2");
        }
        else if(retour==1)
        {
            printf("Date 2 vient avant Date 1");
        }
        else
            printf("Identiques");

    return 0;
}
