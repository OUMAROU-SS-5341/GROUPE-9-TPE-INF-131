#include<stdio.h>
#include<stdlib.h>
#include<math.h>

float carre(float n){
return n*n;
}

int main()
{
    /*Ce programme cr�e une fonction calculant le carr� d'un r�el*/
    float a;
    printf("Entrez le nombre dont vous voulez le carre\n");
    scanf("%f", &a);
    printf("le carre de %.2f est %.2f\n",a,carre(a));
    return 0;
}
