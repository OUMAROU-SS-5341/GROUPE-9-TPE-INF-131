#include <stdio.h>
#include <stdlib.h>

int main()
{
    /*Ce programme permet d'inverser le contenu de deux variables*/
    int a,b,c;
    printf("Entrez la valeur de a \n");
    scanf("%d",&a);
    printf("Entrez la valeur de b \n");
    scanf("%d",&b);
    c=a;
    a=b;
    b=c;
    printf("Les nouvelles valeurs sont: a=%d et  b=%d",a,b);
    return 0;
}
